// Hamburger menu elements
const hamburgerBtn = document.getElementById('hamburger-btn');
const hamburgerMenu = document.getElementById('hamburger-menu');
const hamburgerOverlay = document.getElementById('hamburger-overlay');
const hamburgerClose = document.getElementById('hamburger-close');

function showHamburgerMenu() {
  hamburgerMenu.classList.add('show');
  hamburgerOverlay.classList.add('show');
}

function hideHamburgerMenu() {
  hamburgerMenu.classList.remove('show');
  hamburgerOverlay.classList.remove('show');
}

if (hamburgerBtn) hamburgerBtn.addEventListener('click', showHamburgerMenu);
if (hamburgerClose) hamburgerClose.addEventListener('click', hideHamburgerMenu);
if (hamburgerOverlay) hamburgerOverlay.addEventListener('click', hideHamburgerMenu);

// Data from Docs Page
const docsData = [
  { name: "arXiv", link: "https://arxiv.org", desc: "Open access to 2,000,000+ scientific papers across physics, mathematics, computer science, and more.", cat: "Academic" },
  { name: "Google Scholar", link: "https://scholar.google.com", desc: "Broadly searchable database of scholarly literature across many disciplines and sources.", cat: "Academic" },
  { name: "PubMed Central", link: "https://www.ncbi.nlm.nih.gov/pmc", desc: "Free full-text archive of biomedical and life sciences journal literature at the U.S. NIH.", cat: "Academic" },
  { name: "Library of Congress", link: "https://www.loc.gov", desc: "Largest library in the world, with millions of books, recordings, photographs, newspapers, maps.", cat: "Academic" },
  { name: "Project Gutenberg", link: "https://www.gutenberg.org", desc: "Over 70,000 free eBooks with focus on older works for which U.S. copyright has expired.", cat: "Academic" },
  { name: "Internet Archive", link: "https://archive.org", desc: "Non-profit library of millions of free books, movies, software, music, and more.", cat: "Academic" },
  { name: "JSTOR", link: "https://www.jstor.org", desc: "Digital library of academic journals, books, and primary sources across 75 disciplines.", cat: "Academic" },
  { name: "ScienceDirect", link: "https://www.sciencedirect.com", desc: "Leading platform for peer-reviewed scientific, technical, and medical research.", cat: "Academic" },
  { name: "ResearchGate", link: "https://www.researchgate.net", desc: "Professional network for scientists and researchers to share papers and collaborate.", cat: "Academic" },
  { name: "Academia.edu", link: "https://www.academia.edu", desc: "Platform for academics to share research papers and monitor analytics around their impact.", cat: "Academic" },
  { name: "MIT OpenCourseWare", link: "https://ocw.mit.edu", desc: "Free access to MIT course materials from 2,400+ courses across all departments.", cat: "Academic" },
  { name: "Coursera", link: "https://www.coursera.org", desc: "Online courses and degrees from top universities and companies worldwide.", cat: "Academic" },
  { name: "edX", link: "https://www.edx.org", desc: "Online learning platform offering university-level courses in various disciplines.", cat: "Academic" },
  { name: "Khan Academy", link: "https://www.khanacademy.org", desc: "Non-profit educational organization providing free lessons for students worldwide.", cat: "Academic" },
  { name: "Stanford Encyclopedia of Philosophy", link: "https://plato.stanford.edu", desc: "Comprehensive reference work of philosophical terms and concepts.", cat: "Academic" },
  { name: "Perseus Digital Library", link: "https://www.perseus.tufts.edu", desc: "Digital library of resources for the study of the humanities.", cat: "Academic" },
  { name: "Digital Public Library of America", link: "https://dp.la", desc: "All-purpose digital library offering access to millions of items from libraries, archives, and museums.", cat: "Academic" },
  { name: "World Digital Library", link: "https://www.wdl.org", desc: "International digital library featuring cultural heritage materials from around the world.", cat: "Academic" },
  { name: "Europeana", link: "https://www.europeana.eu", desc: "European digital library with access to millions of books, artworks, and audiovisual materials.", cat: "Academic" },
  { name: "HathiTrust Digital Library", link: "https://www.hathitrust.org", desc: "Large-scale collaborative repository of digital content from research libraries.", cat: "Academic" },
  { name: "Directory of Open Access Journals", link: "https://doaj.org", desc: "Community-curated online directory that indexes and provides access to high quality, open access journals.", cat: "Academic" },
  { name: "OpenDOAR", link: "https://v2.sherpa.ac.uk/opendoar", desc: "Authoritative directory of academic open access repositories.", cat: "Academic" },
  { name: "BASE", link: "https://www.base-search.net", desc: "One of the world's most voluminous search engines for academic web resources.", cat: "Academic" },
  { name: "Semantic Scholar", link: "https://www.semanticscholar.org", desc: "AI-powered research tool for scientific literature, providing context and connections.", cat: "Academic" },
  { name: "Connected Papers", link: "https://www.connectedpapers.com", desc: "Visual tool to help researchers find and explore papers relevant to their field of work.", cat: "Academic" },
  { name: "Exploit-DB", link: "https://www.exploit-db.com", desc: "Comprehensive database of public exploits and corresponding vulnerable software.", cat: "Hacking" },
  { name: "Metasploit Framework", link: "https://www.metasploit.com", desc: "Advanced open-source platform for developing, testing, and executing exploits.", cat: "Hacking" },
  { name: "OWASP Top 10", link: "https://owasp.org/www-project-top-ten", desc: "Standard awareness document representing a broad consensus about the most critical security risks.", cat: "Hacking" },
  { name: "NIST Cybersecurity Framework", link: "https://www.nist.gov/cyberframework", desc: "Policy framework of computer security guidance for private sector organizations.", cat: "Hacking" },
  { name: "CVE Details", link: "https://www.cvedetails.com", desc: "Common Vulnerabilities and Exposures database with detailed information and statistics.", cat: "Hacking" },
  { name: "Packet Storm", link: "https://packetstormsecurity.com", desc: "Information security services, current news, files, and forums.", cat: "Hacking" },
  { name: "SecurityFocus", link: "https://www.securityfocus.com", desc: "Comprehensive security information and vulnerability database.", cat: "Hacking" },
  { name: "The Hacker News", link: "https://thehackernews.com", desc: "Popular news platform for cybersecurity and hacking news.", cat: "Hacking" },
  { name: "Krebs on Security", link: "https://krebsonsecurity.com", desc: "Investigative journalism blog focusing on cybersecurity and cybercrime.", cat: "Hacking" },
  { name: "Schneier on Security", link: "https://www.schneier.com", desc: "Security blog by renowned security expert Bruce Schneier.", cat: "Hacking" },
  { name: "Dark Reading", link: "https://www.darkreading.com", desc: "Cybersecurity news and analysis for security professionals.", cat: "Hacking" },
  { name: "ThreatPost", link: "https://threatpost.com", desc: "Independent news site providing cybersecurity news and analysis.", cat: "Hacking" },
  { name: "Zero Day Initiative", link: "https://www.zerodayinitiative.com", desc: "Vulnerability disclosure and bug bounty program.", cat: "Hacking" },
  { name: "Bugtraq", link: "https://seclists.org/bugtraq", desc: "Full disclosure mailing list for security vulnerabilities.", cat: "Hacking" },
  { name: "Full Disclosure", link: "https://seclists.org/fulldisclosure", desc: "Mailing list for disclosure of security vulnerabilities.", cat: "Hacking" },
  { name: "VulDB", link: "https://vuldb.com", desc: "Vulnerability database with detailed information and risk assessment.", cat: "Hacking" },
  { name: "SecurityTrails", link: "https://securitytrails.com", desc: "Security intelligence platform for threat hunting and attack surface management.", cat: "Hacking" },
  { name: "Risk Based Security", link: "https://www.riskbasedsecurity.com", desc: "Vulnerability intelligence and cyber risk management solutions.", cat: "Hacking" },
  { name: "CISA Alerts", link: "https://www.cisa.gov/news-events/cybersecurity-advisories", desc: "Cybersecurity advisories and alerts from CISA.", cat: "Hacking" },
  { name: "ENISA Advisories", link: "https://www.enisa.europa.eu", desc: "European Union Agency for Cybersecurity publications and advisories.", cat: "Hacking" },
  { name: "MITRE ATT&CK", link: "https://attack.mitre.org", desc: "Framework and knowledge base of adversary tactics and techniques.", cat: "Hacking" },
  { name: "CWE List", link: "https://cwe.mitre.org", desc: "Common Weakness Enumeration - community-developed list of software weakness types.", cat: "Hacking" },
  { name: "The Black Vault", link: "https://www.theblackvault.com", desc: "Largest private archive of declassified government documents (UFOs, etc).", cat: "Intel" },
  { name: "National Security Archive", link: "https://nsarchive.gwu.edu", desc: "Independent non-governmental research institute at George Washington University.", cat: "Intel" },
  { name: "Shodan", link: "https://www.shodan.io", desc: "Search engine for Internet-connected devices and network intelligence.", cat: "Intel" },
  { name: "Censys", link: "https://search.censys.io", desc: "Search engine for discovering devices, networks, and infrastructure.", cat: "Intel" },
  { name: "Public Intelligence", link: "https://publicintelligence.net", desc: "An international, collaborative research project archives government docs.", cat: "Intel" },
  { name: "Papers With Code", link: "https://paperswithcode.com", desc: "The latest in machine learning with code implementations.", cat: "AI" },
  { name: "Hugging Face Papers", link: "https://huggingface.co/papers", desc: "Daily curated list of trending machine learning papers.", cat: "AI" },
  { name: "Distill", link: "https://distill.pub", desc: "Clear explanations of machine learning research papers.", cat: "AI" },
  { name: "OpenAI Research", link: "https://openai.com/research", desc: "Publications and research from OpenAI.", cat: "AI" },
  { name: "Monoskop", link: "https://monoskop.org", desc: "A wiki for collaborative research on art, media, and cultural theory.", cat: "Culture" },
  { name: "UbuWeb", link: "https://ubu.com", desc: "A large web-based educational resource for avant-garde material.", cat: "Culture" },
  { name: "Memory of the World", link: "https://www.memoryoftheworld.org", desc: "A library exploring the past and future of the book.", cat: "Culture" },
  { name: "Patentscope", link: "https://patentscope.wipo.int", desc: "WIPO database for searching international patent applications.", cat: "Legal" },
  { name: "Espacenet", link: "https://worldwide.espacenet.com", desc: "European Patent Office's free online patent search engine.", cat: "Legal" },
  { name: "SEC EDGAR", link: "https://www.sec.gov/cgi-bin/browse-edgar", desc: "Database of company filings submitted to the US SEC.", cat: "Legal" },
  { name: "Journal of Electronic Publishing", link: "https://quod.lib.umich.edu/j/jep", desc: "Exploring issues in electronic publishing and digital documents.", cat: "Academic" },
  { name: "Data.gov", link: "https://data.gov", desc: "U.S. Government's open data repository.", cat: "Data" },
  { name: "Our World in Data", link: "https://ourworldindata.org", desc: "Research and data to make progress against the world's largest problems.", cat: "Data" },
  { name: "Gapminder", link: "https://www.gapminder.org", desc: "Fighting devastating misconceptions about global development.", cat: "Data" },
  { name: "United Nations Treaty Collection", link: "https://treaties.un.org", desc: "Collection of treaties and international agreements.", cat: "Legal" },
  { name: "Vault.fbi.gov", link: "https://vault.fbi.gov", desc: "The FBI's electronic reading room of declassified records.", cat: "Intel" },
  { name: "Marine Traffic", link: "https://www.marinetraffic.com", desc: "Real-time information about ships and their documents/voyages.", cat: "Intel" },
  { name: "Wayback Machine CDX", link: "https://web.archive.org/cdx/search/cdx", desc: "API for querying the Wayback Machine's index history.", cat: "Archive" }
];

function updateClock() {
  const now = new Date();
  const timeEl = document.getElementById('clock-time');
  const dateEl = document.getElementById('clock-date');

  if (timeEl) {
    timeEl.textContent = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  }

  if (dateEl) {
    dateEl.textContent = now.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  }
}

setInterval(updateClock, 1000);
updateClock();

const themeToggle = document.getElementById('theme-toggle');

function initTheme() {
  const savedTheme = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', savedTheme);

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const newTheme = isDark ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('theme', newTheme);
    });

    themeToggle.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        themeToggle.click();
      }
    });
  }
}

const App = {
  config: {
    gridSelector: '#docs-grid',
    filterSelector: '#filter-container',
    countSelector: '#resource-count',
    searchSelector: '#search-input'
  },

  state: {
    rawData: [],
    currentFilter: 'all',
    searchQuery: ''
  },

  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
    },

  getDomain(url) {
    try {
      return new URL(url).hostname.replace('www.', '');
    } catch (e) {
      return 'link';
    }
  },

  createCard(item, index) {
    const safeName = this.escapeHtml(item.name);
    const safeDesc = this.escapeHtml(item.desc);
    const safeCat = this.escapeHtml(item.cat);
    const safeLink = this.escapeHtml(item.link);
    const domain = this.getDomain(item.link);
    const delay = Math.min(index * 0.03, 0.6);

    return `
      <a href="${safeLink}" target="_blank" rel="noopener noreferrer" class="bookmark-card" style="animation-delay: ${delay}s">
        <div class="card-top">
          <h3 class="card-title">${safeName}</h3>
          <svg class="card-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="7" y1="17" x2="17" y2="7"/>
            <polyline points="7 7 17 7 17 17"/>
          </svg>
        </div>
        <div class="card-desc">${safeDesc}</div>
        <div class="card-meta">
          <span class="card-category">${safeCat}</span>
          <span class="card-domain">${domain}</span>
        </div>
      </a>
    `;
  },

  renderFilters(categories) {
    const container = document.querySelector(this.config.filterSelector);
    if (!container) return;

    container.innerHTML = categories.map(cat => {
      const isActive = cat === this.state.currentFilter;
      const label = cat === 'all' ? 'All' : cat;

      return `
        <button class="category-pill ${isActive ? 'active' : ''}" data-cat="${cat}">
          ${label}
        </button>
      `;
    }).join('');
  },

  renderGrid() {
    const grid = document.querySelector(this.config.gridSelector);
    const counter = document.querySelector(this.config.countSelector);
    if (!grid) return;

    const sorted = this.sortData([...this.state.rawData]);
    const filtered = this.filterData(sorted, this.state.currentFilter, this.state.searchQuery);

    if (counter) counter.textContent = filtered.length;

    if (filtered.length === 0) {
      grid.innerHTML = `
        <p class="empty-state" style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-dim);">
          No resources found matching your criteria.
        </p>
      `;
      return;
    }

    grid.innerHTML = filtered.map((item, i) => this.createCard(item, i)).join('');
  },

  handleFilterClick(e) {
    const btn = e.target.closest('.category-pill');
    if (!btn) return;

    const category = btn.dataset.cat;
    this.state.currentFilter = category;

    document.querySelectorAll('.category-pill').forEach(b => {
      b.classList.toggle('active', b.dataset.cat === category);
    });

    this.renderGrid();
  },

  handleSearch(e) {
    this.state.searchQuery = e.target.value;
    this.renderGrid();
  },

  sortData(data) {
    return data.sort((a, b) =>
      (a.name || '').toLowerCase().localeCompare((b.name || '').toLowerCase())
    );
  },

  filterData(data, filter, query) {
    let filtered = data;

    if (filter !== 'all') {
      filtered = filtered.filter(item => (item.cat || '').toLowerCase() === filter.toLowerCase());
    }

    if (query) {
      const searchStr = query.toLowerCase();
      filtered = filtered.filter(item =>
        (item.name || '').toLowerCase().includes(searchStr) ||
        (item.desc || '').toLowerCase().includes(searchStr) ||
        (item.cat || '').toLowerCase().includes(searchStr)
      );
    }

    return filtered;
  },

  getCategories(data) {
    const cats = new Set();
    data.forEach(item => {
      if (item.cat) cats.add(item.cat);
    });

    const preferredOrder = [
      'Academic',
      'Hacking',
      'Intel',
      'AI',
      'Culture',
      'Legal',
      'Data',
      'Archive'
    ];

    const sortedCats = Array.from(cats).sort((a, b) => {
      const ia = preferredOrder.indexOf(a);
      const ib = preferredOrder.indexOf(b);

      if (ia === -1 && ib === -1) return a.localeCompare(b);
      if (ia === -1) return 1;
      if (ib === -1) return -1;
      return ia - ib;
    });

    return ['all', ...sortedCats];
  },

  init() {
    initTheme();
    this.state.rawData = docsData;

    const categories = this.getCategories(this.state.rawData);
    this.renderFilters(categories);
    this.renderGrid();

    const filterContainer = document.querySelector(this.config.filterSelector);
    if (filterContainer) {
      filterContainer.addEventListener('click', this.handleFilterClick.bind(this));
    }

    const searchInput = document.querySelector(this.config.searchSelector);
    if (searchInput) {
      searchInput.addEventListener('input', this.handleSearch.bind(this));
    }
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => App.init());
} else {
  App.init();
}